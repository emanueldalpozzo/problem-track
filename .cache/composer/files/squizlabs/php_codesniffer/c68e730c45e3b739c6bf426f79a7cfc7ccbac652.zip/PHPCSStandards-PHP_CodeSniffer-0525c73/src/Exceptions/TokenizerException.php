<?php
/**
 * An exception thrown by PHP_CodeSniffer when it encounters an unrecoverable tokenizer error.
 *
 * @author    Greg Sherwood <gsherwood@squiz.net>
 * @copyright 2006-2023 Squiz Pty Ltd (ABN 77 084 670 600)
 * @copyright 2023 PHPCSStandards and contributors
 * @license   https://github.com/PHPCSStandards/PHP_CodeSniffer/blob/HEAD/licence.txt BSD Licence
 */

namespace PHP_CodeSniffer\Exceptions;

use Exception;

class TokenizerException extends Exception
{

}
